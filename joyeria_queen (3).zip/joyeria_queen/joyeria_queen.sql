-- ============================================================
--  joyeria_queen  —  Base de datos completa
--  Importar: phpMyAdmin → pestaña SQL → pegar y ejecutar
-- ============================================================

CREATE DATABASE IF NOT EXISTS joyeria_queen
  CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci;
USE joyeria_queen;

-- ── TABLAS ───────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS categorias (
  id         INT(11)      NOT NULL AUTO_INCREMENT,
  nombre     VARCHAR(80)  NOT NULL,
  slug       VARCHAR(80)  NOT NULL,
  creado_en  TIMESTAMP    NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id),
  UNIQUE KEY slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

CREATE TABLE IF NOT EXISTS productos (
  id           INT(11)        NOT NULL AUTO_INCREMENT,
  categoria_id INT(11)        NOT NULL,
  nombre       VARCHAR(120)   NOT NULL,
  descripcion  TEXT           DEFAULT NULL,
  precio       DECIMAL(12,2)  NOT NULL,
  imagen       VARCHAR(255)   DEFAULT NULL,
  destacado    TINYINT(1)     DEFAULT 0,
  activo       TINYINT(1)     DEFAULT 1,
  creado_en    TIMESTAMP      NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id),
  KEY categoria_id (categoria_id),
  CONSTRAINT productos_ibfk_1 FOREIGN KEY (categoria_id) REFERENCES categorias (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

CREATE TABLE IF NOT EXISTS usuarios (
  id         INT(11)      NOT NULL AUTO_INCREMENT,
  nombre     VARCHAR(120) NOT NULL,
  email      VARCHAR(180) NOT NULL,
  password   VARCHAR(255) NOT NULL,
  rol        VARCHAR(20)  NOT NULL DEFAULT 'cliente',
  creado_en  TIMESTAMP    NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id),
  UNIQUE KEY email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

CREATE TABLE IF NOT EXISTS clientes (
  id           INT(11)      NOT NULL AUTO_INCREMENT,
  nombre       VARCHAR(120) NOT NULL,
  cedula       VARCHAR(20)  NOT NULL,
  telefono     VARCHAR(20)  NOT NULL,
  email        VARCHAR(180) NOT NULL,
  direccion    VARCHAR(255) NOT NULL,
  ciudad       VARCHAR(100) NOT NULL,
  departamento VARCHAR(100) NOT NULL,
  creado_en    TIMESTAMP    NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id),
  UNIQUE KEY email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

CREATE TABLE IF NOT EXISTS pedidos (
  id           INT(11)        NOT NULL AUTO_INCREMENT,
  cliente_id   INT(11)        NOT NULL,
  total        DECIMAL(12,2)  NOT NULL,
  metodo_pago  VARCHAR(50)    NOT NULL,
  estado       VARCHAR(30)    NOT NULL DEFAULT 'pendiente',
  notas        TEXT           DEFAULT NULL,
  creado_en    TIMESTAMP      NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id),
  KEY cliente_id (cliente_id),
  CONSTRAINT pedidos_ibfk_1 FOREIGN KEY (cliente_id) REFERENCES clientes (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

CREATE TABLE IF NOT EXISTS detalle_pedidos (
  id           INT(11)       NOT NULL AUTO_INCREMENT,
  pedido_id    INT(11)       NOT NULL,
  producto_id  INT(11)       NOT NULL,
  cantidad     INT(11)       NOT NULL DEFAULT 1,
  precio_unit  DECIMAL(12,2) NOT NULL,
  PRIMARY KEY (id),
  KEY pedido_id (pedido_id),
  KEY producto_id (producto_id),
  CONSTRAINT detalle_pedidos_ibfk_1 FOREIGN KEY (pedido_id)   REFERENCES pedidos (id),
  CONSTRAINT detalle_pedidos_ibfk_2 FOREIGN KEY (producto_id) REFERENCES productos (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

CREATE TABLE IF NOT EXISTS suscriptores (
  id         INT(11)      NOT NULL AUTO_INCREMENT,
  email      VARCHAR(180) NOT NULL,
  activo     TINYINT(1)   DEFAULT 1,
  creado_en  TIMESTAMP    NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id),
  UNIQUE KEY email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- ── CATEGORÍAS ───────────────────────────────────────────────

INSERT INTO categorias (id, nombre, slug) VALUES
  (1, 'Anillos',   'anillos'),
  (2, 'Aretes',    'aretes'),
  (3, 'Collares',  'collares'),
  (4, 'Relojes',   'relojes'),
  (5, 'Pulseras',  'pulseras'),
  (6, 'Mujer',     'mujer'),
  (7, 'Hombre',    'hombre');

-- ── PRODUCTOS (142) ──────────────────────────────────────────

INSERT INTO productos (categoria_id, nombre, descripcion, precio, imagen, destacado, activo) VALUES
  (1, 'Anillo Golden Petals', NULL, 12500000.00, 'imagenes/ani-1.jpeg', 0, 1),
  (1, 'anillo sencillo', NULL, 1500000.00, 'imagenes/ani-2.jpeg', 0, 1),
  (1, 'anillo Aura', NULL, 1850000.00, 'imagenes/ani-1.jpeg', 0, 1),
  (1, 'Anillo Luz Prismática', NULL, 5100000.00, 'imagenes/ani-2.jpeg', 0, 1),
  (1, 'Anillo Corazón Eterno', NULL, 4200000.00, 'imagenes/ani-3.jpeg', 0, 1),
  (1, 'Anillo Corazón Vine', NULL, 1200000.00, 'imagenes/ani-4.jpeg', 0, 1),
  (1, 'Anillo Lavender Wings', NULL, 5100000.00, 'imagenes/ani-5.jpeg', 0, 1),
  (1, 'Anillo Celestial Star', NULL, 1400000.00, 'imagenes/ani-6.jpeg', 0, 1),
  (1, 'Anillo Crown of Love', NULL, 700000.00, 'imagenes/ani-7.jpeg', 0, 1),
  (1, 'Anillo Duo Rosa', NULL, 300000.00, 'imagenes/ani-9.jpeg', 0, 1),
  (1, 'Anillo Tulipán de Oro', NULL, 4200000.00, 'imagenes/ani-10.jpeg', 0, 1),
  (1, 'Anillo Sakura Bloom', NULL, 4300000.00, 'imagenes/ani-11.jpeg', 0, 1),
  (1, 'Anillo Loto de Cristal', NULL, 500000.00, 'imagenes/ani-12.jpeg', 0, 1),
  (1, 'Anillo Vuelo Dorado', NULL, 600000.00, 'imagenes/ani-13.jpeg', 0, 1),
  (1, 'Anillo Copo de Nieve', NULL, 100000.00, 'imagenes/ani-14.jpeg', 0, 1),
  (1, 'Anillo Lazo de Plata', NULL, 200000.00, 'imagenes/ani-15.jpeg', 0, 1),
  (1, 'Anillo Pradera de Margaritas', NULL, 4100000.00, 'imagenes/ani-16.jpeg', 0, 1),
  (1, 'Anillo Río de Estrellas', NULL, 4000000.00, 'imagenes/ani-17.jpeg', 0, 1),
  (1, 'Anillo Aura Floral', NULL, 3200000.00, 'imagenes/ani-18.jpeg', 0, 1),
  (1, 'Anillo Primavera Dual', NULL, 900000.00, 'imagenes/ani-19.jpeg', 0, 1),
  (1, 'Anillo Florecer de Nácar', NULL, 30000.00, 'imagenes/ani-20.jpeg', 0, 1),
  (7, 'estilos para EL', NULL, 18200000.00, 'imagenes/anih-1.jpeg', 0, 1),
  (7, 'Anillo Esencia Áurea', NULL, 650000.00, 'imagenes/anilf-19.jpeg', 0, 1),
  (7, 'Anillo Senda Antigua', NULL, 890000.00, 'imagenes/anilh-2.jpeg', 0, 1),
  (7, 'Anillo Legado Trenzado', NULL, 1200000.00, 'imagenes/anilh-2.jpeg', 0, 1),
  (7, 'Anillo Cruz Imperial', NULL, 420000.00, 'imagenes/anilh-3.jpeg', 0, 1),
  (7, 'Anillo Eslabón Supremo', NULL, 420000.00, 'imagenes/anilh-4.jpeg', 0, 1),
  (7, 'Anillo Sol Áureo Emerald', NULL, 430000.00, 'imagenes/anilh-5.jpeg', 0, 1),
  (7, 'Anillo Horizonte Minimal', NULL, 500000.00, 'imagenes/anilh-6.jpeg', 0, 1),
  (7, 'Anillo Legado Clásico', NULL, 120000.00, 'imagenes/anilh-7.jpeg', 0, 1),
  (7, 'Anillo Reflejo de Plata', NULL, 420000.00, 'imagenes/anilh-8.jpeg', 0, 1),
  (7, 'Anillo Facetas del Rey', NULL, 620000.00, 'imagenes/anilh-9.jpeg', 0, 1),
  (7, 'Anillo Eslabón Supremo Mini', NULL, 400000.00, 'imagenes/anilh-11.jpeg', 0, 1),
  (2, 'Anillo Monolito', NULL, 520000.00, 'imagenes/are-1.jpeg', 0, 1),
  (2, 'Gala Entrelazada', NULL, 310000.00, 'imagenes/arre-2.jpeg', 0, 1),
  (2, 'Brillo Estelar Mini', NULL, 280000.00, 'imagenes/are-3.jpeg', 0, 1),
  (2, 'Duo Floral Blanco', NULL, 450000.00, 'imagenes/are-4.jpeg', 0, 1),
  (2, 'Rocío de Perla', NULL, 610000.00, 'imagenes/are-5.jpeg', 0, 1),
  (2, 'Lágrima de Cristal', NULL, 610000.00, 'imagenes/are-6.jpeg', 0, 1),
  (2, 'Corona de Laurel Gold', NULL, 600000.00, 'imagenes/are-7.jpeg', 0, 1),
  (2, 'Tesoro Marino', NULL, 630000.00, 'imagenes/are-8.jpeg', 0, 1),
  (2, 'Lazo de Pureza', NULL, 510000.00, 'imagenes/are-9.jpeg', 0, 1),
  (2, 'Jardín de Cristal', NULL, 310000.00, 'imagenes/are-10.jpeg', 0, 1),
  (2, 'Arco de Corazón', NULL, 210000.00, 'imagenes/are-11.jpeg', 0, 1),
  (2, 'Lazo Eterno', NULL, 650000.00, 'imagenes/are-12.jpeg', 0, 1),
  (2, 'Vuelo de Mariposa', NULL, 610000.00, 'imagenes/are-13.jpeg', 0, 1),
  (2, 'Destello Invernal', NULL, 610000.00, 'imagenes/are-14.jpeg', 0, 1),
  (2, 'Aura Primaveral', NULL, 610000.00, 'imagenes/are-15.jpeg', 0, 1),
  (2, 'Zafiro Estelar', NULL, 610000.00, 'imagenes/are-16.jpeg', 0, 1),
  (2, 'Pétalos de Nácar', NULL, 610000.00, 'imagenes/are-17.jpeg', 0, 1),
  (2, 'Dúo San Valentín', NULL, 610000.00, 'imagenes/are-18.jpeg', 0, 1),
  (2, 'Cuadro de Ensueño', NULL, 610000.00, 'imagenes/are-19.jpeg', 0, 1),
  (2, 'Tulipán Real', NULL, 610000.00, 'imagenes/are-20.jpeg', 0, 1),
  (2, 'Cisne de Pureza', NULL, 610000.00, 'imagenes/are-21.jpeg', 0, 1),
  (2, 'Deseo Fugaz', NULL, 610000.00, 'imagenes/are-22.jpeg', 0, 1),
  (2, 'Alas de Azur', NULL, 610000.00, 'imagenes/are-23.jpeg', 0, 1),
  (2, 'Latido Radiante', NULL, 610000.00, 'imagenes/are-24.jpeg', 0, 1),
  (2, 'Media Luna Perlada', NULL, 610000.00, 'imagenes/are-25.jpeg', 0, 1),
  (2, 'Esencia de Amor', NULL, 610000.00, 'imagenes/are-26.jpeg', 0, 1),
  (2, 'Lazo de Oro', NULL, 610000.00, 'imagenes/are-27.jpeg', 0, 1),
  (2, 'Flor de Sol', NULL, 610000.00, 'imagenes/are-28.jpeg', 0, 1),
  (2, 'Corazón de Nácar', NULL, 610000.00, 'imagenes/are-29.jpeg', 0, 1),
  (2, 'Pétalo de Cristal', NULL, 610000.00, 'imagenes/are-30.jpeg', 0, 1),
  (2, 'Margarita de Ópalo', NULL, 610000.00, 'imagenes/are-31.jpeg', 0, 1),
  (2, 'Brillo de Loto', NULL, 610000.00, 'imagenes/are-32.jpeg', 0, 1),
  (2, 'Nudo Infinito Gold', NULL, 610000.00, 'imagenes/are-33.jpeg', 0, 1),
  (2, 'Aros de Plata Retorcidos', NULL, 610000.00, 'imagenes/are-34.jpeg', 0, 1),
  (2, 'Argolla Luna Nueva', NULL, 610000.00, 'imagenes/are-35.jpeg', 0, 1),
  (2, 'Gota de Cristal Real', NULL, 610000.00, 'imagenes/are-36.jpeg', 0, 1),
  (2, 'Mariposa Dorada', NULL, 610000.00, 'imagenes/are-37.jpeg', 0, 1),
  (2, 'Pendiente Destello', NULL, 610000.00, 'imagenes/are-38.jpeg', 0, 1),
  (4, 'reloj Cronos Vintage Rose', NULL, 520000.00, 'imagenes/rel-1.jpeg', 0, 1),
  (4, 'Dorado Imperial', NULL, 310000.00, 'imagenes/rel-2.jpeg', 0, 1),
  (4, 'Legado Cuadrante', NULL, 280000.00, 'imagenes/rel-3.jpeg', 0, 1),
  (4, 'Instante de Gala', NULL, 450000.00, 'imagenes/rel-4.jpeg', 0, 1),
  (4, 'Aura Petite Gold', NULL, 610000.00, 'imagenes/rel-5.jpeg', 0, 1),
  (4, 'Perla del Tiempo', NULL, 610000.00, 'imagenes/rel-6.jpeg', 0, 1),
  (4, 'Trío Imperial', NULL, 610000.00, 'imagenes/rel-7.jpeg', 0, 1),
  (4, 'Granate Vintage', NULL, 610000.00, 'imagenes/rel-8.jpeg', 0, 1),
  (4, 'Época Oval', NULL, 610000.00, 'imagenes/rel-9.jpeg', 0, 1),
  (4, 'Cadeneta Luxury', NULL, 610000.00, 'imagenes/rel-10.jpeg', 0, 1),
  (4, 'Línea Eterna', NULL, 610000.00, 'imagenes/rel-11.jpeg', 0, 1),
  (4, 'Dúo Minimalista', NULL, 610000.00, 'imagenes/rel-11.jpeg', 0, 1),
  (4, 'Aura de Época', NULL, 610000.00, 'imagenes/rel-12.jpeg', 0, 1),
  (4, 'Destello Real', NULL, 610000.00, 'imagenes/rel-13.jpeg', 0, 1),
  (4, 'Esencia Gala', NULL, 610000.00, 'imagenes/rel-14.jpeg', 0, 1),
  (4, 'Chocolate Imperial', NULL, 610000.00, 'imagenes/relh-1.jpeg', 0, 1),
  (4, 'Cuarzo Rose Luxury', NULL, 610000.00, 'imagenes/relh-2.jpeg', 0, 1),
  (4, 'Zafiro Ejecutivo', NULL, 610000.00, 'imagenes/relh-3.jpeg', 0, 1),
  (4, 'Cronos Élite Silver', NULL, 610000.00, 'imagenes/relh-4.jpeg', 0, 1),
  (4, 'Azul Medianoche', NULL, 610000.00, 'imagenes/relh-5.jpeg', 0, 1),
  (4, 'Champagne Ejecutivo', NULL, 610000.00, 'imagenes/relh-6.jpeg', 0, 1),
  (4, 'Platino Minimal', NULL, 610000.00, 'imagenes/relh-7.jpeg', 0, 1),
  (4, 'Zafiro President', NULL, 610000.00, 'imagenes/relh-8.jpeg', 0, 1),
  (4, 'Nieve de Acero', NULL, 610000.00, 'imagenes/relh-9.jpeg', 0, 1),
  (4, 'Ónix Nocturno', NULL, 450000.00, 'imagenes/relh-10.jpeg', 0, 1),
  (4, 'Eclipse Silver', NULL, 610000.00, 'imagenes/relh-11.jpeg', 0, 1),
  (4, 'Reflejo Ártico', NULL, 610000.00, 'imagenes/relh-12.jpeg', 0, 1),
  (4, 'Marea Turquesa', NULL, 610000.00, 'imagenes/relh-13.jpeg', 0, 1),
  (3, 'Gargantilla Aura Floral', NULL, 520000.00, 'imagenes/coll-1.jpeg', 0, 1),
  (3, 'Collar Cordón de Plata', NULL, 310000.00, 'imagenes/collh-2.jpeg', 0, 1),
  (3, 'Collar Flor de Cristal', NULL, 450000.00, 'imagenes/coll-3.jpeg', 0, 1),
  (3, 'Collar Cruz Minimal', NULL, 610000.00, 'imagenes/coll-4.jpeg', 0, 1),
  (3, 'Collar Fe Primordial', NULL, 610000.00, 'imagenes/coll-5.jpeg', 0, 1),
  (3, 'Collar Girasol Radiante', NULL, 610000.00, 'imagenes/coll-6.jpeg', 0, 1),
  (3, 'Collar Cisne de Cristal', NULL, 610000.00, 'imagenes/coll-7.jpeg', 0, 1),
  (3, 'Collar Constelación de Perlas', NULL, 610000.00, 'imagenes/coll-8.jpeg', 0, 1),
  (3, 'Collar Halo Circular', NULL, 610000.00, 'imagenes/coll-9.jpeg', 0, 1),
  (3, 'Lágrima de Luz', NULL, 610000.00, 'imagenes/coll-10.jpeg', 0, 1),
  (3, 'Punto de Brillo', NULL, 610000.00, 'imagenes/coll-11.jpeg', 0, 1),
  (3, 'Vínculo Eterno', NULL, 610000.00, 'imagenes/coll-13.jpeg', 0, 1),
  (3, 'Amor Infinito', NULL, 610000.00, 'imagenes/coll-14.jpeg', 0, 1),
  (3, 'Brillo Solar', NULL, 610000.00, 'imagenes/coll-15.jpeg', 0, 1),
  (3, 'Corazón Áureo', NULL, 610000.00, 'imagenes/coll-23.jpeg', 0, 1),
  (3, 'Tesoro de Mar', NULL, 610000.00, 'imagenes/coll-24.jpeg', 0, 1),
  (3, 'Jardín Flotante', NULL, 610000.00, 'imagenes/coll-25.jpeg', 0, 1),
  (3, 'Jardín Real Lavanda', NULL, 610000.00, 'imagenes/coll-26.jpeg', 0, 1),
  (3, 'Dúo Primavera', NULL, 610000.00, 'imagenes/coll-27.jpeg', 0, 1),
  (3, 'Zafiro Marquise', NULL, 610000.00, 'imagenes/coll-28.jpeg', 0, 1),
  (3, 'Perla del Deseo', NULL, 610000.00, 'imagenes/coll-29.jpeg', 0, 1),
  (3, 'Cerezo de Nácar', NULL, 610000.00, 'imagenes/coll-30.jpeg', 0, 1),
  (3, 'Amatista Geométrica', NULL, 610000.00, 'imagenes/coll-31.jpeg', 0, 1),
  (3, 'Destello Rubí', NULL, 610000.00, 'imagenes/coll-32.jpeg', 0, 1),
  (3, 'Gota de Zafiro', NULL, 610000.00, 'imagenes/coll-33.jpeg', 0, 1),
  (3, 'Gargantilla Laurel de Cristal', NULL, 610000.00, 'imagenes/coll-34.jpeg', 0, 1),
  (3, 'Collar Luna de Nácar', NULL, 610000.00, 'imagenes/coll-35.jpeg', 0, 1),
  (3, 'Collar Cuarzo Rosa Luxury', NULL, 610000.00, 'imagenes/coll-36.jpeg', 0, 1),
  (3, 'Gargantilla Vector Gold', NULL, 610000.00, 'imagenes/coll-37.jpeg', 0, 1),
  (3, 'Collar Hoja Áurea', NULL, 610000.00, 'imagenes/coll-38.jpeg', 0, 1),
  (3, 'Collar Rama Esmeralda', NULL, 610000.00, 'imagenes/coll-39.jpeg', 0, 1),
  (3, 'Collar Cordón de Plata (V2)', NULL, 610000.00, 'imagenes/collh-2.jpeg', 0, 1),
  (3, 'Collar Medallón Solar', NULL, 610000.00, 'imagenes/collh-3.jpeg', 0, 1),
  (3, 'Medallón San Benito', NULL, 610000.00, 'imagenes/collh-4.jpeg', 0, 1),
  (3, 'Moneda Imperial', NULL, 610000.00, 'imagenes/collh-5.jpeg', 0, 1),
  (3, 'Cruz de la Fe Gold', NULL, 610000.00, 'imagenes/collh-6.jpeg', 0, 1),
  (3, 'Barra Jeroglífica', NULL, 610000.00, 'imagenes/collh-7.jpeg', 0, 1),
  (3, 'Cadena Eslabón Cubano', NULL, 610000.00, 'imagenes/collh-9.jpeg', 0, 1),
  (3, 'Cadena Fígaro Gold', NULL, 610000.00, 'imagenes/collh-10.jpeg', 0, 1),
  (3, 'Collar Rayo de Energía', NULL, 610000.00, 'imagenes/collh-11.jpeg', 0, 1),
  (3, 'Set Gala de Cristal', NULL, 610000.00, 'imagenes/conj-1.jpeg', 0, 1),
  (3, 'Set Promesa de Amor', NULL, 610000.00, 'imagenes/conj-2.jpeg', 0, 1),
  (3, 'Aura Vintage Petite', NULL, 610000.00, 'imagenes/conj-3.jpeg', 0, 1);

-- Total: 142 productos
